words = ['apple', 'banana', 'cherry', 'date', 'elderberry']
upper_set = {word.upper() for word in words}
print("Uppercase Set:", upper_set)
