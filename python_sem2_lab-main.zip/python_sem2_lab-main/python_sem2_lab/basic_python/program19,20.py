#area of circle
r=10
print((22/7)*r*r)
#area of triangle
h=10
b=15
print((h*b)/2)
