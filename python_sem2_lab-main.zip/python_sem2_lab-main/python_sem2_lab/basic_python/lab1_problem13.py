#bytes into kb,mb,gb
bytes=1024
kb=bytes/1024
mb=kb/1024
gb=mb/1024
print(kb)
print(mb)
print(gb)
