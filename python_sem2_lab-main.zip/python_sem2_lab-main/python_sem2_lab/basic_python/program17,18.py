#perimeter and area of square
a=10
print(4*a)
print(a*a)
#perimeter and area of rectangle
l=10
w=10
print(l*w)
print(2*(l+w))
