#interest
p=10
r=8
n=10
print((p*r*n)/100)
