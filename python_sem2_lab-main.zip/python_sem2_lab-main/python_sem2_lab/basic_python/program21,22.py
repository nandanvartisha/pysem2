#net salary
ts=10000
print(ts+ts*0.10-0.03*ts)
#net sales
gs=1000
print(gs-gs*0.10)
