#hours into minutes
hours=2
print(hours*60)
#minutes into hours
minutes=120
print(minutes/60)
