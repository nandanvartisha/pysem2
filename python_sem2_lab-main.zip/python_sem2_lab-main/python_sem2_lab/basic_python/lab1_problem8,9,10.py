#dollars into Rs.
dollars=2
print(dollars*48)
#Rs. into dollars
rupees=96
print(rupees/48)
#dollars into pounds
print((dollars*48)/70)
