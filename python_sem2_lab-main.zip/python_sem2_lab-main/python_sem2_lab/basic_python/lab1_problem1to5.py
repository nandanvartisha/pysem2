#add two number
a=10
b=5
print(a+b)
#subtract two number
print(a-b)
#multiply two number
print(a*b)
#divide two number
print(a/b)
#add,multiply,subtract,divide
print(a+b)
print(a-b)
print(a*b)
print(a/b)
