#grams into kg
grams=1000
print(grams/1000)
#kg into grams
kg=2
print(kg*1000)
