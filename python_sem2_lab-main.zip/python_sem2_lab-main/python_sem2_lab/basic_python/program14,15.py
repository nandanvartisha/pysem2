#celcius into fahrenhit
cel=23
fer=((9/5)*cel)+32
print(fer)
#fehrenhit into celcius
fer=73.4
cel=5/9*(fer-32)
print(cel)
