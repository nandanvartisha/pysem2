#average of three subject
m1=100
m2=98
m3=93
print((m1+m2+m3)/3)
