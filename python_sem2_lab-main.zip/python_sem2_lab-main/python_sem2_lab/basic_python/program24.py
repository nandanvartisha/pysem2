#swap two values
a=5
b=10
a,b=b,a
print(a,b)
