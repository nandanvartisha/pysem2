N = 10  
for i in range(N, 0, -1):
    print(i)
