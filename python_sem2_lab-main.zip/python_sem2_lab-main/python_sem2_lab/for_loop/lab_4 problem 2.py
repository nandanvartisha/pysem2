n = 5  # Example number
for i in range(1, 11):
    print( f"{n} x {i} = {n * i}")
