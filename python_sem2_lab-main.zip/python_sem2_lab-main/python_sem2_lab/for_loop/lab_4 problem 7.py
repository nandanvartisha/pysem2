import math

n, r = 5, 2  # Example values
nCr = math.comb(n, r)
nPr = math.perm(n, r)
print(f"nCr: {nCr}")
print(f"nPr: {nPr}")
