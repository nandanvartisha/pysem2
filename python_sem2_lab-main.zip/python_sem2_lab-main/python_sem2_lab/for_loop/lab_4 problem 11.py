import math

degrees = 45  # Example value
x = degrees * (math.pi / 180)
sin_x = math.sin(x)
print(f"sin(x): {sin_x}")
