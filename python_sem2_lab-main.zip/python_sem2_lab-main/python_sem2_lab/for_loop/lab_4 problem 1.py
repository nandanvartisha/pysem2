import string

print("Uppercase Alphabets:", string.ascii_uppercase)
print("Lowercase Alphabets:", string.ascii_lowercase)
