import math

n = 5  # Example number
factorial = math.factorial(n)
print(factorial)
