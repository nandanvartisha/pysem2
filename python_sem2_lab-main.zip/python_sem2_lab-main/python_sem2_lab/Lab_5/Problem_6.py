fen=int(input("Enter fernhit value : "))
cel=(fen-32)*(5/9)
print(f"{fen} fernhit is {cel} celcius")
