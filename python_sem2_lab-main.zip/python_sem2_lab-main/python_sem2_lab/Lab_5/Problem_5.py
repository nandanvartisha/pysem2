lt=["bghhghg","k","e","n","tur"]
for i in range(5):
    lt[i]=lt[i].upper()
print(lt)
