a = [1, 2, 3, 4, 5, 6]
b = [6, 5, 4, 3, 2, 1]
c = list(map(lambda x, y: x + y, a, b))
print(c)
