def fun(): print("fun")
def disp(): print("disp")
def msg(): print("msg")

for f in [fun, disp, msg]:
    f()
