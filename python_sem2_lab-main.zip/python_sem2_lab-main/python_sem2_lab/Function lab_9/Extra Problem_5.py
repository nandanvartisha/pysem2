names = ['Alexander', 'John', 'Christopher', 'Emily', 'Elizabeth']
long_names = list(filter(lambda name: len(name) > 8, names))
print(long_names)
