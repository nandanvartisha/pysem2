dictionary = {}
if not dictionary:
    print("The dictionary is empty.")
else:
    print("The dictionary is not empty.")
