a,b=10,50
if a>b:
    print("a is the largest")
    print("b is the smallest")
else:
    print("b is the largest")
    print("a is the smallest")
