a=int(input("Ente first  angle : "))
b=int(input("Ente second angle : "))
c=int(input("Ente third angle : "))
if a+b+c==180:
    print("Valid")
else:
    print("Not valid")
