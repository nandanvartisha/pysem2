l=float(input("Enter length :  "))
b=float(input("Enter breadth : "))
per=2*(l+b)
area=l*b
if per>area:
     print("Perimeter is greater")
else:
    print("Area is greater")
