age=17
if age<18:
    print("Minor")
else:
    print("Major")
