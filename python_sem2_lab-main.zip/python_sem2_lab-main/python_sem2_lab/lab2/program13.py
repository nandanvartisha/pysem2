from num2words import num2words
num=int(input("Enter a number : "))
print(num2words(num))
