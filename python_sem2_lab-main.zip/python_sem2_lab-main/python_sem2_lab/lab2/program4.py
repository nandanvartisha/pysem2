n=52
if n%10==0:
    print("Divide by 10")
else:
    print("Do not divide by ten")
