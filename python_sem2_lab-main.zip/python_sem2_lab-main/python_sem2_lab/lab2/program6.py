a=1000
n=0
while a!=0:
    a=a//10
    n+=1
print(n)
