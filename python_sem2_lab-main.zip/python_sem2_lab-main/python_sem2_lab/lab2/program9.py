a=int(input("Enter a : "))
if a>0:
    print(f"{a} is absoulate")
else:
    a=-a
    print(f"Absoulate value is {a}")
